<!DOCTYPE html>
<html lang="en">
<head>
  <title>Payment Success</title>
  <meta charset="utf-8">
  <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Kanit:wght@600&display=swap" rel="stylesheet">
</head>
<body>
	<style>
	.container,.container2{
		display: flex;
		justify-content: center;
		align-items: center;
	}
	h2{
		font-weight: bold;
		color:#bc1010;
		font-size:80px;
		font-family: 'Kanit', sans-serif;
	}
	</style>

<div class="container">
    <img src="https://xp.io/storage/18TAOY6T.png" width="300">
</div>
<div class="container2">
	<h2>Payment Failed</h2>
</div>


</body>
</html>
