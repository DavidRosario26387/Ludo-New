<?php $__env->startSection('title'); ?>
    All Testimonial List
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <!--  link custom css link here -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- BEGIN: Content-->
    <div class="row">
        <!-- Bootstrap Validation -->
        <div class="col-md-12 col-12">
            <div class="card">
                <div class="card-header">
                    <p class="card-title"><i class="las la-sliders-h"></i> All Testimonial List</p>
                    <a href="<?php echo e(url('/')); ?>/admin/testimonial/add"><button class="btn btn-orange border-0 round"><i
                                class="las la-plus-circle"></i> Add New Testimonial</button></a>
                </div>
                <?php if(session()->get('error')): ?>
                    <div class="alert alert-danger alert-dismissible ml-1 mr-1" id="notice_msg" role="alert">
                        <div class="alert-body">
                            <b><?php echo e(session()->get('error')); ?></b>
                        </div>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php elseif(session()->get('success')): ?>
                    <div class="alert alert-success alert-dismissible ml-1 mr-1" id="success_msg" role="alert">
                        <div class="alert-body">
                            <b><?php echo e(session()->get('success')); ?></b>
                        </div>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Image</th>
                                    <th>User Name</th>
                                    <th>Designation</th>
                                    <th>User Mail</th>
                                    <th>No. Of Star</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><span class="font-weight-bold"><?php echo e($data->firstItem() + $key); ?></span></td>
                                        <td><img src="<?php echo e(url('/')); ?>/storage/Testimonial/<?php echo e($result->profile_image); ?>"
                                                width="30"></td>
                                        <td><?php echo e($result->username); ?></td>
                                        <td><?php echo e($result->Designation); ?></td>
                                        <td><?php echo e($result->usermail); ?></td>
                                        <td>
                                            <?php if($result->Star == '1'): ?>
                                                <i class="las la-star text-warning"></i>
                                            <?php elseif($result->Star == '2'): ?>
                                                <i class="las la-star text-warning"></i>
                                                <i class="las la-star text-warning"></i>
                                            <?php elseif($result->Star == '3'): ?>
                                                <i class="las la-star text-warning"></i>
                                                <i class="las la-star text-warning"></i>
                                                <i class="las la-star text-warning"></i>
                                            <?php elseif($result->Star == '4'): ?>
                                                <i class="las la-star text-warning"></i>
                                                <i class="las la-star text-warning"></i>
                                                <i class="las la-star text-warning"></i>
                                                <i class="las la-star text-warning"></i>
                                            <?php elseif($result->Star == '5'): ?>
                                                <i class="las la-star text-warning"></i>
                                                <i class="las la-star text-warning"></i>
                                                <i class="las la-star text-warning"></i>
                                                <i class="las la-star text-warning"></i>
                                                <i class="las la-star text-warning"></i>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <button type="button" view-id="<?php echo e($result->id); ?>"
                                                view-username="<?php echo e($result->username); ?>"
                                                view-Designation="<?php echo e($result->Designation); ?>"
                                                view-usermail="<?php echo e($result->usermail); ?>"
                                                view-Star="<?php echo e($result->Star); ?>" view-Review="<?php echo e($result->Review); ?>"
                                                view-date="<?php echo e($result->submit_date); ?>" title="View" data-toggle="modal"
                                                data-target="#ViewDetails"
                                                class="btn btn-icon btn-icon rounded-circle btn-info bg-darken-4 border-0 view_buttion">
                                                <i class="las la-eye"></i>
                                            </button>
                                            <button type="button" delete-id="<?php echo e($result->id); ?>" data-toggle="tooltip"
                                                data-placement="top" title="Delete"
                                                class="btn btn-icon btn-icon rounded-circle btn-danger bg-darken-4 border-0 delete_buuton">
                                                <i class="las la-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="my-1">
                        <?php echo e($data->onEachSide(3)->links('vendor.pagination.custom')); ?>

                    </div>
                </div>
            </div>
        </div>
        <!-- /Bootstrap Validation -->
    </div>

    <div class="d-inline-block">
        <!-- Button trigger modal -->
        <!-- Modal -->
        <div class="modal fade text-left modal-success" id="ViewDetails" tabindex="-1" role="dialog"
            aria-labelledby="myModalLabel110" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="myModalLabel110"></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <table class="table table-bordered">
                            <tr>
                                <td>User Name</td>
                                <td class="username"></td>
                            </tr>
                            <tr>
                                <td>Email</td>
                                <td class="useremail"></td>
                            </tr>
                            <tr>
                                <td>Designation</td>
                                <td class="userDesignation"></td>
                            </tr>
                            <tr>
                                <td>Start</td>
                                <td class="userstart"></td>
                            </tr>
                            <tr>
                                <td>Review</td>
                                <td class="userreview"></td>
                            </tr>
                            <tr>
                                <td>Submit Date</td>
                                <td class="submitdatehai"></td>
                            </tr>
                        </table>


                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END: Content-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(URL::asset('admin-assets/css/custom/js/Testimonial/Testimonial.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/spludo/public_html/resources/views/admin/Testimonial/AllTestimonial.blade.php ENDPATH**/ ?>