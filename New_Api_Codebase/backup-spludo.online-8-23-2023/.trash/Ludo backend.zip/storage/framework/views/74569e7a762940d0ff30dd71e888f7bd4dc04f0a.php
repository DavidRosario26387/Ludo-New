<?php $__env->startSection('title'); ?>
 Top Player
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
 <!--  link custom css link here -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
 <!-- BEGIN: Content-->
   <div class="row">
     <!-- Bootstrap Validation -->
      <div class="col-md-12 col-12">
        <div class="card">
          <div class="card-header">
            <p class="card-title"><i class="las la-sliders-h"></i> Top Player List</p>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table">
                <thead>
                  <tr>
                    <th>Rank</th>
                    <th>Player ID</th>
                    <th>Player Name</th>
                    <th>Gmail ID</th>
                    <th>Total Coin</th>
                    <th>Win Coin</th>
                    <th>Game Played</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $userdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><span class="font-weight-bold"><?php echo e($userdata->firstItem() + $key); ?> <i class="las la-trophy"></i></span></td>
                    <td><?php echo e($result->playerid); ?></td>
                    <td><?php echo e($result->username); ?></td>
                    <td><?php echo e($result->useremail); ?></td>
                    <td><?php echo e($result->playcoin); ?> ₹</td>
                    <td><?php echo e($result->wincoin); ?> ₹</td>
                    <td><?php echo e($result->GamePlayed); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
            <div class="my-1">
            <?php echo e($userdata->onEachSide(3)->links('vendor.pagination.custom')); ?>

            </div>
          </div>
        </div>
      </div>
      <!-- /Bootstrap Validation -->

  </div>
    <!-- END: Content-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(URL::asset('admin-assets/css/custom/js/FAQ/faq.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/spludo/public_html/resources/views/admin/Home/Leaderboard.blade.php ENDPATH**/ ?>