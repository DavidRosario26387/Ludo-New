<?php $__env->startSection('title'); ?>
 New Withdraw Request
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
 <!--  link custom css link here -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
 <!-- BEGIN: Content-->
   <div class="row">
     <!-- Bootstrap Validation -->
      <div class="col-md-12 col-12">
        <div class="card">
          <div class="card-header">
            <p class="card-title"><i class="las la-sliders-h"></i> New Withdraw Request List</p>
          </div>
              <?php if(session()->get('error')): ?>
            <div class="alert alert-danger alert-dismissible ml-1 mr-1" id="notice_msg" role="alert">
                <div class="alert-body">
                 <b><?php echo e(session()->get('error')); ?></b>
                </div>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
                 <?php elseif(session()->get('success')): ?>
                    <div class="alert alert-success alert-dismissible ml-1 mr-1" id="success_msg" role="alert">
                        <div class="alert-body">
                         <b><?php echo e(session()->get('success')); ?></b>
                        </div>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>
          <div class="card-body">
          <div class="table-responsive">
              <table class="table">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Player ID</th>
                    <th>Payment Method</th>
                    <th>Account</th>
                    <th>Amount</th>
                    <th>Txn ID</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><span class="font-weight-bold"><?php echo e($data->firstItem() + $key); ?></span></td>
                     <td><?php echo e($result->userid); ?></td>
                     <td><?php echo e($result->payment_method); ?></td>
                    <td>

                      <?php if($result->payment_method !='Bank Account'): ?>
                         Acount - <?php echo e($result->account_number); ?><br>
                      <?php else: ?>
                       Name - <?php echo e($result->bank_name); ?> <br>
                       A/C - <?php echo e($result->account_number); ?><br>
                       IFSC Code - <?php echo e($result->ifsc_code); ?><br>
                      <?php endif; ?>

                    </td>

                    <td><?php echo e($result->amount); ?> ₹</td>
                    <td>
                      <?php if($result->transaction_id !=""): ?>
                       <?php echo e($result->transaction_id); ?>

                      <?php else: ?>
                      Amount Pending
                      <?php endif; ?>
                    </td>
                    <td>
                    <div class="badge badge-light-warning">Pending</div>
                   </td>
                   <td>
                        <button type="button" data-trans="<?php echo e($result->transaction_id); ?>" data-requestid="<?php echo e($result->id); ?>" data-pay="<?php echo e($result->payment_method); ?>" data-id="<?php echo e($result->userid); ?>" data-username="Jhone Doe" data-status="<?php echo e($result->status); ?>" data-toggle="modal" data-target="#addCoin" title="Edit" class="btn btn-icon btn-icon rounded-circle btn-primary bg-darken-4 border-0 edit_buuton">
                         <i class="las la-highlighter"></i>
                        </button>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
            <div class="my-1">
            <?php echo e($data->onEachSide(3)->links('vendor.pagination.custom')); ?>

            </div>
          </div>
        </div>
      </div>
      <!-- /Bootstrap Validation -->
  </div>
      <div class="d-inline-block">
              <!-- Button trigger modal -->
              <!-- Modal -->
        <div class="modal fade text-left modal-success" id="addCoin" tabindex="-1" role="dialog" aria-labelledby="myModalLabel110" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title userTitle" id="myModalLabel110"></h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">
                      <form method="post" action="<?php echo e(route('update.withdraw.status')); ?>" data-parsley-validate autocomplete="off">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                        <label>ID <span class="text-danger required-sign">*</span></label>
                        <input type="text" value="" readonly class="form-control request_id" name="RequestID" required />
                        </div>
                        <div class="form-group">
                        <label>Player ID <span class="text-danger required-sign">*</span></label>
                        <input type="text" readonly class="form-control player_id" name="PlayerID" required />
                        </div>
                        <div class="form-group d-none">
                        <label>Player Name <span class="text-danger required-sign">*</span></label>
                        <input type="text" value="Jone Doe" readonly class="form-control player_name" name="PlayerName" required />
                        </div>
                        <div class="form-group">
                        <label>Payment Method <span class="text-danger required-sign">*</span></label>
                        <input type="text" readonly class="form-control payment_method" name="payment_method" required />
                        </div>
                        <div class="form-group">
                        <label>Transaction ID <span class="text-danger required-sign">*</span></label>
                        <input type="text" class="form-control transaction_id" name="transaction_id" required />
                        </div>
                        <div class="form-group">
                        <label>Transaction Status <span class="text-danger required-sign">*</span></label>
                         <select class="select2 form-control form-control-lg status" required name="status">
                         </select>
                       </div>
                       <div class="row my-2">
                      <div class="col-12">
                      <button type="submit" class="btn btn-orange float-right border-0 submit_btn">Submit</button>
                      </div>
                    </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
    <!-- END: Content-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(URL::asset('admin-assets/css/custom/js/player/player.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/spludo/public_html/resources/views/admin/Withdraw/PendingWithdraw.blade.php ENDPATH**/ ?>