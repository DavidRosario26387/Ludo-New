<?php $__env->startSection('title'); ?>
 Admin Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
 <!--  link custom css link here -->
 <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('admin-assets/css/plugins/charts/chart-apex.min.css')); ?>">
 <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('admin-assets/vendors/css/charts/apexcharts.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
 <!-- Dashboard Ecommerce Starts -->
<section id="dashboard-analytics">
   <!-- Line Chart Card -->
  <div class="row">
    <div class="col-lg-4 col-sm-6 col-12">
      <div class="card">
        <div class="card-header align-items-start pb-0">
          <div>
            <h2 class="font-weight-bolder">
            <?php if($Todays >= 1000): ?>
            <?php echo e($Todays/1000); ?> K
            <?php else: ?>
            <?php echo e($Todays); ?>

            <?php endif; ?>
            </h2>
            <p class="card-text mb-2">Today's Register Player</p>
          </div>
          <div class="avatar bg-success p-50">
            <div class="avatar-content">
             <i class="las la-user-friends font-medium-5"></i>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-4 col-sm-6 col-12">
        <div class="card">
          <div class="card-header align-items-start pb-0">
            <div>
              <h2 class="font-weight-bolder">
                <?php if($totalUser > 1000): ?>
                <?php echo e($totalUser/1000); ?> K
                <?php else: ?>
                <?php echo e($totalUser); ?>

                <?php endif; ?>
              </h2>
              <p class="card-text mb-2">Total Register Player</p>
            </div>
            <div class="avatar bg-warning p-50">
              <div class="avatar-content">
               <i class="las la-users font-medium-5"></i>
              </div>
            </div>
          </div>
        </div>
      </div>
    <div class="col-lg-4 col-sm-6 col-12">
      <div class="card">
        <div class="card-header align-items-start pb-0">
          <div>
            <h2 class="font-weight-bolder">
                <?php if($OwnerAmount > 1000): ?>
                <?php echo e($OwnerAmount/1000); ?> K ₹</i>
                <?php else: ?>
                <?php echo e($OwnerAmount); ?> ₹</i>
                <?php endif; ?>
            </h2>
            <p class="card-text mb-2">Owner Approx Income</p>
          </div>
          <div class="avatar bg-danger p-50">
            <div class="avatar-content">
             <i class="las la-wallet font-medium-5"></i>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--/ Line Chart Card -->

  <!-- Line Area Chart Card -->
  <div class="row">
    <div class="col-lg-3 col-sm-6 col-12">
      <div class="card">
        <div class="card-header flex-column align-items-start pb-0">
          <div class="avatar bg-primary p-50 m-0">
            <div class="avatar-content">
             <i class="las la-rupee-sign font-medium-5"></i>
            </div>
          </div>
          <h2 class="font-weight-bolder mt-1">
            <?php if($WinningAmount > 1000): ?>
            <?php echo e($WinningAmount/1000); ?> K
            <?php else: ?>
            <?php echo e($WinningAmount); ?>

            <?php endif; ?>
           ₹</i></h2>
          <p class="card-text">Total Winning Amount</p>
        </div>
        <div id="line-area-chart-1"></div>
      </div>
    </div>
    <div class="col-lg-3 col-sm-6 col-12">
      <div class="card">
        <div class="card-header flex-column align-items-start pb-0">
          <div class="avatar bg-success p-50 m-0">
            <div class="avatar-content">
              <i class="las la-rupee-sign font-medium-5"></i>
            </div>
          </div>
          <h2 class="font-weight-bolder mt-1">
            <?php if($WalletAmount > 1000): ?>
            <?php echo e($WalletAmount/1000); ?> K
            <?php else: ?>
            <?php echo e($WalletAmount); ?>

            <?php endif; ?>

            ₹</i></h2>
          <p class="card-text">Total Wallet Amount</p>
        </div>
        <div id="line-area-chart-2"></div>
      </div>
    </div>
    <div class="col-lg-3 col-sm-6 col-12">
      <div class="card">
        <div class="card-header flex-column align-items-start pb-0">
          <div class="avatar bg-warning p-50 m-0">
            <div class="avatar-content">
              <i class="las la-exchange-alt font-medium-5"></i>
            </div>
          </div>
          <h2 class="font-weight-bolder mt-1">
            <?php if($AllTransaction > 1000): ?>
            <?php echo e($AllTransaction/1000); ?> K
            <?php else: ?>
            <?php echo e($AllTransaction); ?>

            <?php endif; ?>
          </h2>
          <p class="card-text">Total Transaction</p>
        </div>
        <div id="line-area-chart-3"></div>
      </div>
    </div>

    <div class="col-lg-3 col-sm-6 col-12">
      <div class="card">
        <div class="card-header flex-column align-items-start pb-0">
          <div class="avatar bg-success p-50 m-0">
            <div class="avatar-content">
              <i class="las la-paper-plane font-medium-5"></i>
            </div>
          </div>
          <h2 class="font-weight-bolder mt-1">
            <?php if($TotalSentMoney > 1000): ?>
            <?php echo e($TotalSentMoney/1000); ?> K
            <?php else: ?>
            <?php echo e($TotalSentMoney); ?>

            <?php endif; ?>
           ₹</i></h2>
          <p class="card-text">Total Amount Sent</p>
        </div>
        <div id="line-area-chart-4"></div>
      </div>
    </div>
  </div>
  <!--/ Line Area Chart Card -->
    <!-- Line Chart Card -->
  <div class="row">
    <div class="col-lg-4 col-sm-6 col-12">
      <div class="card">
        <div class="card-header align-items-start pb-0">
          <div>
            <h2 class="font-weight-bolder">
            <?php if($TotalPendingWithRequest > 1000): ?>
            <?php echo e($TotalPendingWithRequest/1000); ?> K
            <?php else: ?>
            <?php echo e($TotalPendingWithRequest); ?>

            <?php endif; ?>
            </h2>
            <p class="card-text mb-2">Pending Withdraw Request</p>
          </div>
          <div class="avatar bg-warning p-50">
            <div class="avatar-content">
             <i class="las la-hand-holding-usd font-medium-5"></i>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-4 col-sm-6 col-12">
      <div class="card">
        <div class="card-header align-items-start pb-0">
          <div>
            <h2 class="font-weight-bolder">
            <?php if($TotalApprovedWithRequest > 1000): ?>
            <?php echo e($TotalApprovedWithRequest/1000); ?> K
            <?php else: ?>
            <?php echo e($TotalApprovedWithRequest); ?>

            <?php endif; ?>
            </h2>
            <p class="card-text mb-2">Approved Withdraw Request</p>
          </div>
          <div class="avatar bg-success p-50">
            <div class="avatar-content">
             <i class="las la-check-circle font-medium-5"></i>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-4 col-sm-6 col-12">
      <div class="card">
        <div class="card-header align-items-start pb-0">
          <div>
            <h2 class="font-weight-bolder">
            <?php if($TotalRejectWithRequest > 1000): ?>
            <?php echo e($TotalRejectWithRequest/1000); ?> K
            <?php else: ?>
            <?php echo e($TotalRejectWithRequest); ?>

            <?php endif; ?>
            </h2>
            <p class="card-text mb-2">Reject Withdraw Request</p>
          </div>
          <div class="avatar bg-danger p-50">
            <div class="avatar-content">
             <i class="las la-times-circle font-medium-5"></i>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--/ Line Chart Card -->



  <div class="row match-height">
    <!-- Timeline Card -->
    <div class="col-lg-4 col-12">
      <div class="card">
      <div class="card-header">
        <p class="card-title"><i class="las la-users"></i> Recent New Registration</p>
      </div>
      <div class="table-responsive">
        <table class="table">
          <thead>
            <tr>
              <th>#</th>
              <th>Player ID</th>
              <th>Name</th>
              <th>Images</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $Userdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><span class="font-weight-bold"><?php echo e($Userdata->firstItem() + $key); ?></span></td>
              <td><?php echo e($result->playerid); ?></td>
              <td><?php echo e($result->username); ?></td>
              <td>
                <?php if($result['photo'] == null): ?>
                <img src="https://xp.io/storage/6YUfyNd.png" width="50">
                <?php else: ?>
                <img src="<?php echo e($result->photo); ?>" width="50">
               <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
    </div>
    <!--/ Timeline Card -->
    <!-- Timeline Card -->
    <div class="col-lg-4 col-12">
      <div class="card">
      <div class="card-header">
         <p class="card-title"><i class="las la-exchange-alt"></i> Recent Transaction</p>
      </div>
      <div class="table-responsive">
        <table class="table">
          <thead>
            <tr>
              <th>#</th>
              <th>User ID</th>
              <th>Amount</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $Transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><span class="font-weight-bold"><?php echo e($Transaction->firstItem() + $key); ?></span></td>
              <td><?php echo e($result->userid); ?></td>
              <td><b><?php echo e($result->amount); ?> ₹</b></td>
              <td>
                <?php if($result->status == "Success"): ?>
              <div class="badge badge-light-success">Success</div>
                <?php else: ?>
              <div class="badge badge-light-danger">Failed</div>
                <?php endif; ?>

              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
    </div>
    <!--/ Timeline Card -->
    <!-- Timeline Card -->
    <div class="col-lg-4 col-12">
      <div class="card">
      <div class="card-header">
        <p class="card-title"><i class="las la-hand-holding-usd"></i> Recent Withdraw</p>
      </div>
      <div class="table-responsive">
        <table class="table">
          <thead>
            <tr>
              <th>#</th>
              <th>User ID</th>
              <th>Amount</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $Withdraw; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><span class="font-weight-bold"><?php echo e($Withdraw->firstItem() + $key); ?></span></td>
              <td><?php echo e($result->userid); ?></td>
              <td><b><?php echo e($result->amount); ?> ₹</b></td>
              <td>
                <?php if($result->status == 1): ?>
              <div class="badge badge-light-success">Success</div>
                <?php else: ?>
              <div class="badge badge-light-danger">Failed</div>
                <?php endif; ?>

              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
    </div>
    <!--/ Timeline Card -->



    <!--/ Timeline Card -->
  </div>

</section>
<!-- Dashboard Ecommerce ends -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
 <script src="<?php echo e(URL::asset('admin-assets/vendors/js/charts/apexcharts.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('admin-assets/js/scripts/cards/card-statistics.min.js')); ?>"></script>
<!-- link custom js link here -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/spludo/public_html/resources/views/admin/index.blade.php ENDPATH**/ ?>