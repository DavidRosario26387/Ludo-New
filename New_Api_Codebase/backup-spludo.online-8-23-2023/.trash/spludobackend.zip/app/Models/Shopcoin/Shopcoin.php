<?php

namespace App\Models\Shopcoin;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class Shopcoin extends Model
{
    use HasFactory;
    protected $fillable = [
        "shop_coin",
        ];
    
}
