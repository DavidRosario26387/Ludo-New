<?php if(isset($_GET['success'])) { ?>
    <center>
        <h1>Payment is under review! we will add your coin after verifying your payment. Stay tuned...</h1>
    
    <small>If in 24 hours your amount is not credited in your account, please contact us on given email or contact us button</small>
    </center>
<?php } else {?>
   <center>
        <h1>Sorry! your payment is not completed! Please try again later...</h1>
   </center>
<?php } ?>


