 @foreach($user_device as $user)

    <h2>{{$user->device_token}}</h2>

    @endforeach