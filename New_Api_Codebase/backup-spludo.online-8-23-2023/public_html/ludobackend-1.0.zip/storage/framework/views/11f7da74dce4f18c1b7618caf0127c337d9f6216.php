<?php $__env->startSection('title'); ?>
 All Contact
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
 <!--  link custom css link here -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
 <!-- BEGIN: Content-->
   <div class="row">
     <!-- Bootstrap Validation -->
      <div class="col-md-12 col-12">
        <div class="card">
          <div class="card-header">
            <p class="card-title"><i class="las la-sliders-h"></i> All Contact List</p>
          </div>
              <?php if(session()->get('error')): ?>
            <div class="alert alert-danger alert-dismissible ml-1 mr-1" id="notice_msg" role="alert">
                <div class="alert-body">
                 <b><?php echo e(session()->get('error')); ?></b>
                </div>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
                 <?php elseif(session()->get('success')): ?>
                    <div class="alert alert-success alert-dismissible ml-1 mr-1" id="success_msg" role="alert">
                        <div class="alert-body">
                         <b><?php echo e(session()->get('success')); ?></b>
                        </div>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Subject</th>
                    <th>Message</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $contact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><span class="font-weight-bold"><?php echo e($contact->firstItem() + $key); ?></span></td>
                    <td><?php echo e($result->name); ?></td>
                    <td><?php echo e($result->email); ?></td>
                    <td><?php echo e($result->subject); ?></td>
                    <td><?php echo e($result->message); ?></td>
                    <td>
                      <button type="button"  data-name="<?php echo e($result->name); ?>" data-email="<?php echo e($result->email); ?>" data-subject="<?php echo e($result->subject); ?>" data-message="<?php echo e($result->message); ?>"  data-toggle="modal" data-target="#addCoin" data-placement="top" title="View" class="btn btn-icon btn-icon rounded-circle btn-success bg-darken-4 border-0 view_buuton">
                       <i class="las la-eye"></i>
                      </button>
                      <button type="button" delete-id="<?php echo e($result->id); ?>" data-toggle="tooltip" data-placement="top" title="Delete" class="btn btn-icon btn-icon rounded-circle btn-danger bg-darken-4 border-0 delete_buuton">
                       <i class="las la-trash"></i>
                      </button>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
            <div class="my-1">
            <?php echo e($contact->onEachSide(3)->links('vendor.pagination.custom')); ?>

            </div>
          </div>
        </div>
      </div>
      <!-- /Bootstrap Validation -->

<div class="d-inline-block">
        <!-- Button trigger modal -->
        <!-- Modal -->
  <div class="modal fade text-left modal-success" id="addCoin" tabindex="-1" role="dialog" aria-labelledby="myModalLabel110" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel110"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <form method="post" action="<?php echo e(route('add.user.coin')); ?>" data-parsley-validate autocomplete="off">
                  <?php echo csrf_field(); ?>
                  <div class="form-group">
                  <label>Player Name <span class="text-danger required-sign">*</span></label>
                  <input type="text" readonly class="form-control player_name border-0" name="PlayerName" required />
                  </div>
                  <div class="form-group">
                  <label>Email <span class="text-danger required-sign">*</span></label>
                  <input type="text" readonly class="form-control total_coin border-0" name="TotalCoin" required />
                  </div>
                  <div class="form-group">
                  <label>Subject <span class="text-danger required-sign">*</span></label>
                  <input type="text" readonly class="form-control totalwin_coin border-0" name="TotalWinCoin" required />
                  </div>
                  <div class="form-group">
                  <label>Message <span class="text-danger required-sign">*</span></label>
                  <textarea type="number" readonly class="form-control coin_value border-0" name="CoinValue" rows="4"></textarea>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>




  </div>
    <!-- END: Content-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(URL::asset('admin-assets/css/custom/js/contact/contact.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/spludo/public_html/resources/views/admin/Contact/Contact.blade.php ENDPATH**/ ?>