<?php $__env->startSection('title'); ?>
 All Success Transcrion List
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
 <!--  link custom css link here -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
 <!-- BEGIN: Content-->
   <div class="row">
     <!-- Bootstrap Validation -->
      <div class="col-md-12 col-12">
        <div class="card">
          <div class="card-header">
            <p class="card-title"><i class="las la-sliders-h"></i> All Success Transcrion List</p>
          </div>
              <?php if(session()->get('error')): ?>
            <div class="alert alert-danger alert-dismissible ml-1 mr-1" id="notice_msg" role="alert">
                <div class="alert-body">
                 <b><?php echo e(session()->get('error')); ?></b>
                </div>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
                 <?php elseif(session()->get('success')): ?>
                    <div class="alert alert-success alert-dismissible ml-1 mr-1" id="success_msg" role="alert">
                        <div class="alert-body">
                         <b><?php echo e(session()->get('success')); ?></b>
                        </div>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>
          <div class="card-body">
          <div class="table-responsive">
              <table class="table">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>User ID</th>
                    <th>Order ID</th>
                    <th>Txn ID</th>
                    <th>Amount</th>
                    <th>Status</th>
                     <th>Date</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><span class="font-weight-bold"><?php echo e($data->firstItem() + $key); ?></span></td>
                    <td><?php echo e($result->userid); ?></td>
                    <td><?php echo e($result->order_id); ?></td>
                    <td><?php echo e($result->txn_id); ?></td>
                    <td><?php echo e($result->amount); ?> ₹</td>
                    <td><div class="badge badge-light-success">Success</div></td>
                    <td><?php echo e($result->trans_date); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
            <div class="my-1">
            <?php echo e($data->onEachSide(3)->links('vendor.pagination.custom')); ?>

            </div>
          </div>
        </div>
      </div>
      <!-- /Bootstrap Validation -->
  </div>

    <!-- END: Content-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/spludo/public_html/resources/views/admin/Transaction/SuccessTransaction.blade.php ENDPATH**/ ?>