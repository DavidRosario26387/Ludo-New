<?php $__env->startSection('title'); ?>
 Bid Value
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
 <!--  link custom css link here -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
 <!-- BEGIN: Content-->
   <div class="row">
   <!-- Bootstrap Validation -->
    <div class="col-md-5 col-12">
      <div class="card">
        <div class="card-header">
          <p class="card-title"><i class="las la-certificate"></i> Add New Bid Value</p>
        </div>
            <?php if(session()->get('error')): ?>
          <div class="alert alert-danger alert-dismissible ml-1 mr-1" id="notice_msg" role="alert">
              <div class="alert-body">
               <b><?php echo e(session()->get('error')); ?></b>
              </div>
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
               <?php elseif(session()->get('success')): ?>
                  <div class="alert alert-success alert-dismissible ml-1 mr-1" id="success_msg" role="alert">
                      <div class="alert-body">
                       <b><?php echo e(session()->get('success')); ?></b>
                      </div>
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                  </div>
              <?php endif; ?>
        <div class="card-body">
          <form class="create_brand" method="post" action="<?php echo e(route('create.bidvalue.new')); ?>" enctype="multipart/form-data" data-parsley-validate autocomplete="off">
            <?php echo csrf_field(); ?>
            <div class="form-group">
              <label>Add Bid Value <span class="text-danger required-sign">*</span></label>
              <input type="number" class="form-control bid_value" name="bid_value" required />
            </div>
            <div class="row my-3">
              <div class="col-12">
              <button type="submit" class="btn btn-orange float-right border-0 submit_btn">Submit</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
    <!-- /Bootstrap Validation -->
    <!-- Merged -->
    <div class="col-md-7 col-12">
          <div class="card">
      <div class="card-header">
        <p class="card-title"><i class="las la-certificate"></i> All Bid Value</p>
      </div>
      <div class="table-responsive">
        <table class="table">
          <thead>
            <tr>
              <th>#</th>
              <th>Bid Value</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><span class="font-weight-bold"><?php echo e($brands->firstItem() + $key); ?></span></td>
              <td><span class="font-weight-bold"><?php echo e($result->bid_value); ?> ₹</span></td>
              <td>
              <button type="button" data-id="<?php echo e($result->id); ?>" data-toggle="tooltip" data-placement="top" title="Edit" class="btn btn-icon btn-icon rounded-circle btn-primary bg-darken-4 border-0 edit_buuton">
               <i class="las la-highlighter"></i>
              </button>
              <button type="button" delete-id="<?php echo e($result->id); ?>" data-toggle="tooltip" data-placement="top" title="Delete" class="btn btn-icon btn-icon rounded-circle btn-danger bg-darken-4 border-0 delete_buuton">
               <i class="las la-trash"></i>
              </button>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
      <div class="my-1">
        <?php echo e($brands->onEachSide(3)->links('vendor.pagination.custom')); ?>

      </div>
    </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<!-- link custom js link here -->
<script src="<?php echo e(URL::asset('admin-assets/css/custom/js/bidvalue/bidvalue.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/spludo/public_html/resources/views/admin/Bidvalue/Bidvalue.blade.php ENDPATH**/ ?>