<?php
    $admin = DB::table('admins')->first();
    $websettings = DB::table('websettings')->first();
?>

<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
  <!-- BEGIN: Head-->
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="Webplustech Solutinos,Ludo Game,Ludo Game Development Company">
    <meta name="keywords" content="Webplustech Solutinos,Ludo Game,Ludo Game Development Company">
    <meta name="author" content="Webplustech Solutinos">
    <?php echo $__env->make('admin.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>
  <!-- END: Head-->
  <!-- BEGIN: Body-->
  <body class="vertical-layout vertical-menu-modern navbar-floating footer-static <?php echo e($websettings->skin_mode); ?>" data-open="click" data-menu="vertical-menu-modern" data-col="" token="<?php echo e(csrf_token()); ?>">

    <!-- BEGIN: Header-->
    <nav class="header-navbar navbar navbar-expand-lg align-items-center floating-nav navbar-light navbar-shadow">
      <?php echo $__env->make('admin.layout.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </nav>
    <!-- END: Header-->
   <?php echo $__env->make('admin.layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- BEGIN: Content-->
    <div class="app-content content ">
      <div class="content-overlay"></div>
      <div class="header-navbar-shadow"></div>
      <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body">

         <?php echo $__env->yieldContent('content'); ?>

        </div>
      </div>
    </div>
    <!-- END: Content-->
    </div>
 <?php echo $__env->make('admin.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
  <!-- END: Body-->
</html>
<?php /**PATH /home/spludo/public_html/resources/views/admin/layout/master.blade.php ENDPATH**/ ?>