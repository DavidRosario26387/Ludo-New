$(document).ready(function(){
	"use strict";
	setTimeout(function() {
    $('#notice_msg').fadeOut('fast');
}, 3000); // <-- time in milliseconds
});